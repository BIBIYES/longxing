<template>
  <div>
    <div class="max-box" v-for="(item, index) in json" :key="index" ref="boxRefs">
      <p>{{ item.name }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const json = ref([
  { name: "香蕉" },
  { name: "苹果" },
  { name: "西瓜" },
  { name: "橙子" }
]);

const boxRefs = ref([]);

onMounted(() => {
  if (boxRefs.value.length > 0) {
    const lastElement = boxRefs.value[boxRefs.value.length - 1];
    console.log('最后一个子元素：', lastElement);

    // 创建一个带类的新元素
    const loadingElement = document.createElement('div');
    loadingElement.classList.add('loading');
    // 添加新元素到最后一个子元素后面
    lastElement.appendChild(loadingElement);
  }
});
</script>

<style>
.max-box {
  width: 200px;
  height: 100px;
  background-color: red;
  margin-bottom: 10px;
  padding: 10px;
}

.loading {
  width: 20px;
  height: 20px;
  background-color: green;
  margin-top: 5px;
}
</style>
